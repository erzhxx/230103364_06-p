"""Module 3 - Warp Intrinsics, Synchronization & Atomics (Tasks 18-20 so far)."""
import numpy as np
from numba import cuda, float32

FULL_MASK = 0xFFFFFFFF
WARP = 32
SCAN_MAX = 1024  # largest single-block scan (Tasks 20-21)


# --------------------------------------------------------------------------
# Task 18: Warp-level sum reduction with shuffle intrinsics
# Each block writes one partial sum to out_arr[blockIdx.x].
# blockDim.x: multiple of 32, <= 1024.
# --------------------------------------------------------------------------
@cuda.jit
def warp_reduce_sum_shfl(in_arr, out_arr):
    warp_sums = cuda.shared.array(shape=WARP, dtype=float32)
    tid = cuda.threadIdx.x
    lane = tid % WARP
    warp_id = tid // WARP
    i = cuda.blockIdx.x * cuda.blockDim.x + tid

    val = in_arr[i] if i < in_arr.size else float32(0.0)

    # Intra-warp tree reduction: no shared memory, no block barrier.
    for delta in (16, 8, 4, 2, 1):
        val += cuda.shfl_down_sync(FULL_MASK, val, delta)
    # lane 0 of every warp now holds that warp's sum.
    if lane == 0:
        warp_sums[warp_id] = val
    cuda.syncthreads()

    # The first warp aggregates the per-warp sums.
    if warp_id == 0:
        num_warps = (cuda.blockDim.x + WARP - 1) // WARP
        v = warp_sums[lane] if lane < num_warps else float32(0.0)
        for delta in (16, 8, 4, 2, 1):
            v += cuda.shfl_down_sync(FULL_MASK, v, delta)
        if lane == 0:
            out_arr[cuda.blockIdx.x] = v


# --------------------------------------------------------------------------
# Task 19: Warp vote functions & divergence analysis
# Predicate: data[i] > 0.
#   mask_out[w]  = ballot bitmask of warp w (bit L set <=> lane L satisfied it)
# Threads past the end of `data` vote False.
# mask_out must be uint32 with one entry per warp (grid_threads // 32).
# --------------------------------------------------------------------------
@cuda.jit
def warp_vote_analyzer(data, mask_out):
    tid = cuda.threadIdx.x
    i = cuda.blockIdx.x * cuda.blockDim.x + tid
    pred = (i < data.size) and (data[i] > 0)
    ballot = cuda.ballot_sync(FULL_MASK, pred)
    if tid % WARP == 0:
        mask_out[i // WARP] = ballot


@cuda.jit
def warp_vote_summary(data, all_out, any_out, ballot_out):
    """Companion kernel: per-warp all / any / ballot results (uint8/uint8/uint32)."""
    tid = cuda.threadIdx.x
    i = cuda.blockIdx.x * cuda.blockDim.x + tid
    pred = (i < data.size) and (data[i] > 0)
    all_true = cuda.all_sync(FULL_MASK, pred)
    any_true = cuda.any_sync(FULL_MASK, pred)
    ballot = cuda.ballot_sync(FULL_MASK, pred)
    if tid % WARP == 0:
        w = i // WARP
        all_out[w] = 1 if all_true else 0
        any_out[w] = 1 if any_true else 0
        ballot_out[w] = ballot


# --------------------------------------------------------------------------
# Task 20: Hillis-Steele inclusive scan (single block, double-buffered)
# Launch: one block, blockDim.x >= len(x), blockDim.x <= 1024.
# --------------------------------------------------------------------------
@cuda.jit
def scan_hillis_steele(x, out):
    buf = cuda.shared.array(shape=2 * SCAN_MAX, dtype=float32)  # ping-pong
    tid = cuda.threadIdx.x
    n = x.size
    bd = cuda.blockDim.x

    buf[tid] = x[tid] if tid < n else 0.0
    pin = 0
    offset = 1
    cuda.syncthreads()
    while offset < bd:
        pout = 1 - pin
        v = buf[pin * SCAN_MAX + tid]
        if tid >= offset:
            v += buf[pin * SCAN_MAX + tid - offset]
        buf[pout * SCAN_MAX + tid] = v
        cuda.syncthreads()
        pin = pout
        offset *= 2

    if tid < n:
        out[tid] = buf[pin * SCAN_MAX + tid]
