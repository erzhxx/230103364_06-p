"""Module 1 - CUDA Execution Model (Tasks 1-8).

All functions are Numba CUDA kernels. Launch them as ``kernel[grid, block](...)``
using the configurations listed in each task specification.
"""
import numpy as np
from numba import cuda, float32, uint8


# --------------------------------------------------------------------------
# Task 01: 1D Vector Addition with Boundary Checks
# Launch: blockDim=(256,), gridDim=((N + 255) // 256,)
# --------------------------------------------------------------------------
@cuda.jit
def vector_add_1d(a, b, out):
    i = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    if i < out.size:
        out[i] = a[i] + b[i]


# --------------------------------------------------------------------------
# Task 02: 1D Grid-Stride Loop Element-wise Scaling
# Launch: fixed grid (e.g. 64 blocks x 256 threads), independent of N.
# --------------------------------------------------------------------------
@cuda.jit
def vector_scale_grid_stride(x, alpha, out):
    start = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    stride = cuda.gridDim.x * cuda.blockDim.x
    for i in range(start, x.size, stride):
        out[i] = x[i] * alpha


# --------------------------------------------------------------------------
# Task 03: 2D Matrix Element-wise Addition & Index Mapping
# Launch: blockDim=(16, 16), gridDim=((N + 15)//16, (M + 15)//16)
# --------------------------------------------------------------------------
@cuda.jit
def matrix_add_2d(A, B, C):
    row = cuda.blockIdx.y * cuda.blockDim.y + cuda.threadIdx.y
    col = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    if row < A.shape[0] and col < A.shape[1]:
        C[row, col] = A[row, col] + B[row, col]


# --------------------------------------------------------------------------
# Task 04: 2D Matrix Transpose (Naive Global Memory)
# A: (M, N) -> B: (N, M). Reads coalesced, writes strided.
# Launch: blockDim=(16, 16), gridDim=((N + 15)//16, (M + 15)//16)
# --------------------------------------------------------------------------
@cuda.jit
def matrix_transpose_naive(A, B):
    row = cuda.blockIdx.y * cuda.blockDim.y + cuda.threadIdx.y
    col = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    if row < A.shape[0] and col < A.shape[1]:
        B[col, row] = A[row, col]


# --------------------------------------------------------------------------
# Task 05: 3D Grid Volume Initialization & Index Flattening
# vol[z, y, x] = z * 10000 + y * 100 + x
# Launch: blockDim=(8, 8, 8), gridDim=((W+7)//8, (H+7)//8, (D+7)//8)
# --------------------------------------------------------------------------
@cuda.jit
def volume_init_3d(vol, D, H, W):
    x = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    y = cuda.blockIdx.y * cuda.blockDim.y + cuda.threadIdx.y
    z = cuda.blockIdx.z * cuda.blockDim.z + cuda.threadIdx.z
    if x < W and y < H and z < D:
        # Row-major flattened offset of this element is z*H*W + y*W + x.
        vol[z, y, x] = z * 10000 + y * 100 + x


# --------------------------------------------------------------------------
# Task 06: RGB -> Grayscale (ITU-R BT.601), uint8 or float32 input
# img_rgb: (H, W, 3), img_gray: (H, W) float32 (or float64)
# Launch: 2D grid covering (H, W), e.g. blockDim=(16, 16).
# --------------------------------------------------------------------------
@cuda.jit
def rgb_to_grayscale(img_rgb, img_gray):
    x = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    y = cuda.blockIdx.y * cuda.blockDim.y + cuda.threadIdx.y
    if y < img_gray.shape[0] and x < img_gray.shape[1]:
        r = img_rgb[y, x, 0]
        g = img_rgb[y, x, 1]
        b = img_rgb[y, x, 2]
        img_gray[y, x] = 0.299 * r + 0.587 * g + 0.114 * b


# --------------------------------------------------------------------------
# Task 07: Vector LERP, out = (1 - t) * a + t * b  (fused multiply-add)
# Launch: 1D grid, boundary checked.
# --------------------------------------------------------------------------
@cuda.jit
def vector_lerp(a, b, t, out):
    i = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    if i < out.size:
        tv = t[i]
        one = float32(1.0)  # keep everything float32 (a float literal would promote to float64)
        # fma(t, b, (1 - t) * a) == (1 - t) * a + t * b with a single rounding
        out[i] = cuda.fma(tv, b[i], (one - tv) * a[i])


# --------------------------------------------------------------------------
# Task 08: Threshold -> uint8 mask, branch-free, grid-stride loop
# --------------------------------------------------------------------------
@cuda.jit
def vector_threshold(x, thresh, mask):
    start = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    stride = cuda.gridDim.x * cuda.blockDim.x
    for i in range(start, x.size, stride):
        mask[i] = uint8(x[i] >= thresh)  # predicated compare, no if/else
