"""Module 2 - Memory Hierarchy & Shared Memory (Tasks 9-17)."""
import numpy as np
from numba import cuda, float32, int64

# Compile-time constants (shared-memory shapes must be known at compile time).
BLOCK = 256            # default 1D block size used by Tasks 9-11
MAX_RADIUS = 32        # largest stencil radius supported by Task 10
MAX_K = 64             # largest filter length supported by Task 11
TILE = 16              # matmul tile (Task 12)
T32 = 32               # transpose tile (Task 13)
MAX_THREADS = 1024     # upper bound for reduction block size (Tasks 14-15)


# --------------------------------------------------------------------------
# Task 09: Coalesced vs Strided Memory Access
# out[i] = in[(i * stride) % n]. stride == 1 is a plain coalesced copy;
# stride == 32 makes every lane of a warp touch a different 128-byte line.
# Launch: blockDim=(256,), gridDim=((N + 255) // 256,)
# --------------------------------------------------------------------------
@cuda.jit
def benchmark_strided_access(in_arr, out_arr, stride):
    i = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
    n = in_arr.size
    if i < n:
        out_arr[i] = in_arr[(i * stride) % n]


def measure_strided_bandwidth(n=1 << 24, strides=(1, 2, 4, 8, 16, 32), repeats=20):
    """Return {stride: effective GB/s} measured with CUDA events."""
    h = np.random.rand(n).astype(np.float32)
    d_in = cuda.to_device(h)
    d_out = cuda.device_array_like(d_in)
    grid = (n + BLOCK - 1) // BLOCK
    result = {}
    for s in strides:
        benchmark_strided_access[grid, BLOCK](d_in, d_out, s)  # warm-up / JIT
        cuda.synchronize()
        start, end = cuda.event(), cuda.event()
        start.record()
        for _ in range(repeats):
            benchmark_strided_access[grid, BLOCK](d_in, d_out, s)
        end.record()
        end.synchronize()
        ms = cuda.event_elapsed_time(start, end) / repeats
        result[s] = (2 * n * 4) / (ms * 1e-3) / 1e9  # read + write bytes
    return result


# --------------------------------------------------------------------------
# Task 10: 1D Stencil / Moving Average with shared-memory halo
# Matches scipy.ndimage.uniform_filter1d(size=2R+1, mode='nearest').
# Launch: blockDim=(256,), gridDim=((N + 255) // 256,), radius <= MAX_RADIUS
# --------------------------------------------------------------------------
@cuda.jit
def stencil_1d_shared(in_arr, out_arr, radius):
    tile = cuda.shared.array(shape=BLOCK + 2 * MAX_RADIUS, dtype=float32)
    tid = cuda.threadIdx.x
    n = in_arr.size
    base = cuda.blockIdx.x * BLOCK

    # Cooperative load of center + both halos with index clamping.
    for k in range(tid, BLOCK + 2 * radius, BLOCK):
        g = base + k - radius
        if g < 0:
            g = 0
        elif g > n - 1:
            g = n - 1
        tile[k] = in_arr[g]
    cuda.syncthreads()

    i = base + tid
    if i < n:
        acc = float32(0.0)
        for j in range(2 * radius + 1):
            acc += tile[tid + j]
        out_arr[i] = acc / float32(2 * radius + 1)


# --------------------------------------------------------------------------
# Task 11: 1D Convolution with shared-memory tiling
# Matches np.convolve(x, kernel, mode='same') for len(kernel) <= len(x).
# y[i] = sum_k kernel[k] * x[i + (K-1)//2 - k]   (zero padded)
# Launch: blockDim=(256,), gridDim=((N + 255) // 256,), K <= MAX_K
# --------------------------------------------------------------------------
@cuda.jit
def conv_1d_shared_tiled(x, kernel, y):
    s_x = cuda.shared.array(shape=BLOCK + MAX_K - 1, dtype=float32)
    s_k = cuda.shared.array(shape=MAX_K, dtype=float32)
    tid = cuda.threadIdx.x
    n = x.size
    K = kernel.size
    c = (K - 1) // 2
    base = cuda.blockIdx.x * BLOCK

    # Filter -> shared memory
    if tid < K:
        s_k[tid] = kernel[tid]
    # Signal tile: s_x[t] holds x[base + t + c - (K - 1)] (zero outside [0, n))
    for t in range(tid, BLOCK + K - 1, BLOCK):
        g = base + t + c - (K - 1)
        if g >= 0 and g < n:
            s_x[t] = x[g]
        else:
            s_x[t] = 0.0
    cuda.syncthreads()

    i = base + tid
    if i < n:
        acc = float32(0.0)
        for k in range(K):
            # x[i + c - k] lives at tile index (i - base) + c - k - c + (K - 1)
            acc += s_k[k] * s_x[tid + (K - 1) - k]
        y[i] = acc


# --------------------------------------------------------------------------
# Task 12: 2D Tiled Matrix Multiplication, C = A (M x K) @ B (K x N)
# Launch: blockDim=(16, 16), gridDim=((N + 15)//16, (M + 15)//16)
# --------------------------------------------------------------------------
@cuda.jit
def matmul_tiled_shared(A, B, C):
    sA = cuda.shared.array((TILE, TILE), dtype=float32)
    sB = cuda.shared.array((TILE, TILE), dtype=float32)
    tx = cuda.threadIdx.x
    ty = cuda.threadIdx.y
    row = cuda.blockIdx.y * TILE + ty
    col = cuda.blockIdx.x * TILE + tx
    M = A.shape[0]
    K = A.shape[1]
    N = B.shape[1]

    acc = float32(0.0)
    num_tiles = (K + TILE - 1) // TILE
    for p in range(num_tiles):
        a_col = p * TILE + tx
        b_row = p * TILE + ty
        sA[ty, tx] = A[row, a_col] if (row < M and a_col < K) else 0.0
        sB[ty, tx] = B[b_row, col] if (b_row < K and col < N) else 0.0
        cuda.syncthreads()
        for k in range(TILE):
            acc += sA[ty, k] * sB[k, tx]
        cuda.syncthreads()

    if row < M and col < N:
        C[row, col] = acc


# --------------------------------------------------------------------------
# Task 13: Bank-conflict-free transpose (32 x 33 padded tile)
# A: (M, N) -> B: (N, M)
# Launch: blockDim=(32, 32) or (32, 8); gridDim=((N + 31)//32, (M + 31)//32)
# --------------------------------------------------------------------------
@cuda.jit
def transpose_bank_conflict_free(A, B):
    tile = cuda.shared.array((T32, T32 + 1), dtype=float32)  # +1 column padding
    tx = cuda.threadIdx.x
    M = A.shape[0]
    N = A.shape[1]

    x_in = cuda.blockIdx.x * T32 + tx
    for j in range(cuda.threadIdx.y, T32, cuda.blockDim.y):
        y_in = cuda.blockIdx.y * T32 + j
        if x_in < N and y_in < M:
            tile[j, tx] = A[y_in, x_in]          # coalesced read
    cuda.syncthreads()

    x_out = cuda.blockIdx.y * T32 + tx           # column index in B (< M)
    for j in range(cuda.threadIdx.y, T32, cuda.blockDim.y):
        y_out = cuda.blockIdx.x * T32 + j        # row index in B (< N)
        if x_out < M and y_out < N:
            B[y_out, x_out] = tile[tx, j]        # coalesced write


# --------------------------------------------------------------------------
# Task 14: Parallel tree sum reduction (sequential addressing)
# blockDim.x must be a power of two <= 1024. Each block writes one partial sum.
# --------------------------------------------------------------------------
@cuda.jit
def reduction_sum_shared(in_arr, block_sums):
    sdata = cuda.shared.array(shape=MAX_THREADS, dtype=float32)
    tid = cuda.threadIdx.x
    i = cuda.blockIdx.x * cuda.blockDim.x + tid
    sdata[tid] = in_arr[i] if i < in_arr.size else 0.0
    cuda.syncthreads()

    stride = cuda.blockDim.x >> 1
    while stride > 0:
        if tid < stride:
            sdata[tid] += sdata[tid + stride]
        cuda.syncthreads()
        stride >>= 1

    if tid == 0:
        block_sums[cuda.blockIdx.x] = sdata[0]


# --------------------------------------------------------------------------
# Task 15: Parallel argmax reduction (value + 64-bit global index)
# Ties resolve to the smallest index. blockDim.x: power of two <= 1024.
# block_max_indices must be an int64 array.
# --------------------------------------------------------------------------
@cuda.jit
def reduction_argmax_shared(in_arr, block_max_vals, block_max_indices):
    s_val = cuda.shared.array(shape=MAX_THREADS, dtype=float32)
    s_idx = cuda.shared.array(shape=MAX_THREADS, dtype=int64)
    tid = cuda.threadIdx.x
    i = cuda.blockIdx.x * cuda.blockDim.x + tid
    if i < in_arr.size:
        s_val[tid] = in_arr[i]
        s_idx[tid] = i
    else:
        s_val[tid] = -np.inf
        s_idx[tid] = 9223372036854775807  # INT64_MAX: loses every tie
    cuda.syncthreads()

    stride = cuda.blockDim.x >> 1
    while stride > 0:
        if tid < stride:
            ov = s_val[tid + stride]
            oi = s_idx[tid + stride]
            if ov > s_val[tid] or (ov == s_val[tid] and oi < s_idx[tid]):
                s_val[tid] = ov
                s_idx[tid] = oi
        cuda.syncthreads()
        stride >>= 1

    if tid == 0:
        block_max_vals[cuda.blockIdx.x] = s_val[0]
        block_max_indices[cuda.blockIdx.x] = s_idx[0]


# --------------------------------------------------------------------------
# Task 16: Constant-memory FIR filter (64 taps)
# The weights are baked into constant memory at compile time. The default
# kernel uses FIR_WEIGHTS; make_constant_memory_filter(w) builds one for any
# 1D weight array. Output matches np.convolve(signal, weights, mode='same').
# Launch: blockDim=(256,), gridDim=((N + 255) // 256,)
# --------------------------------------------------------------------------
def make_constant_memory_filter(weights):
    weights = np.ascontiguousarray(weights, dtype=np.float32)
    taps = weights.size
    centre = (taps - 1) // 2

    @cuda.jit
    def constant_memory_filter(signal, out):
        w = cuda.const.array_like(weights)   # same address for the whole warp
        i = cuda.blockIdx.x * cuda.blockDim.x + cuda.threadIdx.x
        n = signal.size
        if i < n:
            acc = float32(0.0)
            for k in range(taps):
                g = i + centre - k
                if g >= 0 and g < n:
                    acc += w[k] * signal[g]
            out[i] = acc

    return constant_memory_filter


# Deterministic default 64-tap low-pass filter (Hamming-windowed sinc, sum = 1).
_n = np.arange(64, dtype=np.float64)
_h = np.sinc(0.25 * (_n - 31.5)) * np.hamming(64)
FIR_WEIGHTS = (_h / _h.sum()).astype(np.float32)
del _n, _h

constant_memory_filter = make_constant_memory_filter(FIR_WEIGHTS)


# --------------------------------------------------------------------------
# Task 17: Pinned vs pageable host memory transfer benchmark (host function)
# --------------------------------------------------------------------------
def benchmark_pinned_transfer(size_bytes, repeats=10):
    """Compare pageable vs pinned PCIe throughput (GB/s) using CUDA events.

    Returns a dict with h2d/d2h bandwidth for both memory kinds, the pinned /
    pageable speed-up ratios and an ``integrity`` flag (round-trip equality).
    """
    size_bytes = int(size_bytes)
    rng = np.random.default_rng(0)
    src = rng.integers(0, 256, size_bytes, dtype=np.uint8)

    pageable_in = src.copy()
    pageable_out = np.empty_like(src)
    pinned_in = cuda.pinned_array(size_bytes, dtype=np.uint8)
    pinned_out = cuda.pinned_array(size_bytes, dtype=np.uint8)
    pinned_in[:] = src

    d_buf = cuda.device_array(size_bytes, dtype=np.uint8)
    stream = cuda.stream()

    def timed(fn):
        fn()                                  # warm-up
        stream.synchronize()
        times = []
        for _ in range(repeats):
            start, end = cuda.event(), cuda.event()
            start.record(stream)
            fn()
            end.record(stream)
            end.synchronize()
            times.append(cuda.event_elapsed_time(start, end))
        ms = float(np.median(times))
        return size_bytes / (ms * 1e-3) / 1e9

    res = {
        "pageable_h2d_gbps": timed(lambda: d_buf.copy_to_device(pageable_in, stream=stream)),
        "pinned_h2d_gbps": timed(lambda: d_buf.copy_to_device(pinned_in, stream=stream)),
    }
    res["pageable_d2h_gbps"] = timed(lambda: d_buf.copy_to_host(pageable_out, stream=stream))
    res["pinned_d2h_gbps"] = timed(lambda: d_buf.copy_to_host(pinned_out, stream=stream))
    res["h2d_speedup"] = res["pinned_h2d_gbps"] / res["pageable_h2d_gbps"]
    res["d2h_speedup"] = res["pinned_d2h_gbps"] / res["pageable_d2h_gbps"]

    # Integrity: pinned host -> device -> pinned host must be bit-identical.
    d_buf.copy_to_device(pinned_in, stream=stream)
    d_buf.copy_to_host(pinned_out, stream=stream)
    stream.synchronize()
    res["integrity"] = bool(np.array_equal(pinned_out, src))
    return res
